# The Meal DB Flutter Apps

## API Powered by themealdb.com

Screenshots
-----------

![Main Menu](screenshots/main.png "A list of meals")
![Meals details](screenshots/detail.png "Details for a specific meals")
![Favorite meals](screenshots/favorite.png "Details for a specific meals")

Credit : [Sagar Suri](https://github.com/SAGARSURI/MyMovies)
